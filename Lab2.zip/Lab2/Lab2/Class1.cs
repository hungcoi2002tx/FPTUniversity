﻿namespace Lab2_NguyenHoan
{
    public class Class1
    {

    }
}